Component({
  data: {},
});
