Component({
  data: {},
});
